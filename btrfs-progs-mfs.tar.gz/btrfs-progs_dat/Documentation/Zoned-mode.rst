Zoned mode
==========

.. include:: ch-zoned-intro.rst
