Swapfile
========

.. include:: ch-swapfile.rst
