Hardware considerations
=======================

.. include:: ch-hardware-considerations.rst
