Seeding device
==============

.. include:: ch-seeding-device.rst
