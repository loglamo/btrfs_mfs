Checksumming
============

.. include:: ch-checksumming.rst
